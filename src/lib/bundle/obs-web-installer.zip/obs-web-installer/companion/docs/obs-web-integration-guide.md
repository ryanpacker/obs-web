# obs-web Integration Guide

This document contains everything needed to implement auto-connect in the obs-web fork. It describes what obs-web-companion does, what data it publishes, and how obs-web should consume that data.

## Background

obs-web is a browser-based remote control for OBS Studio. It connects to OBS via WebSocket using an IP address and port that the user manually enters. The problem: the OBS host machine's IP changes whenever DHCP leases renew or the network connection changes, forcing the user to re-discover and re-enter it.

obs-web-companion solves this by running a script on the OBS host machine that detects the local IP and publishes it to a shared Convex database. The obs-web fork reads from that same database and auto-connects — no manual IP entry required.

## Architecture

```
┌─────────────────────┐         ┌──────────────┐         ┌──────────────────┐
│  OBS Host Machine   │         │    Convex    │         │   obs-web (browser)│
│                     │         │              │         │                    │
│  obs-web-companion  │──publish──▶ hostConfig ◀──read────│  auto-connect     │
│  (publish-ip.ts)    │   IP     │   table     │  IP      │  logic            │
└─────────────────────┘         └──────────────┘         └──────────────────┘
```

## Convex Project Details

- **Convex project**: `obs-web-companion` (team: `ryan-packer`)
- **Deployment URL**: `https://useful-pika-111.convex.cloud`

Both repos (obs-web-companion and obs-web) share the same Convex project. obs-web-companion defines the schema and mutations; obs-web only needs to read from it.

## Convex Schema

The database has a single table, `hostConfig`, with one record that gets upserted on each publish:

```typescript
// convex/schema.ts
hostConfig: defineTable({
  ipAddress: v.string(),       // e.g. "192.168.1.42"
  interfaceType: v.string(),   // "Ethernet" or "Wi-Fi"
  interfaceName: v.string(),   // e.g. "Ethernet Adapter (en4)" or "Wi-Fi (en0)"
  updatedAt: v.number(),       // Date.now() timestamp (ms since epoch)
})
```

## Convex Query

obs-web-companion defines a `getHost` query that returns the single hostConfig record:

```typescript
// convex/obsHost.ts
export const getHost = query({
  args: {},
  handler: async (ctx) => {
    return await ctx.db.query("hostConfig").first();
  },
});
```

The return type is:

```typescript
{
  _id: Id<"hostConfig">;
  _creationTime: number;
  ipAddress: string;
  interfaceType: string;   // "Ethernet" | "Wi-Fi"
  interfaceName: string;
  updatedAt: number;
} | null  // null if no IP has been published yet
```

## What obs-web Needs To Do

### 1. Add the Convex client dependency

obs-web needs the `convex` npm package to connect to the shared Convex backend.

### 2. Connect to the Convex project

obs-web needs to connect to the same Convex deployment. The deployment URL is:

```
https://useful-pika-111.convex.cloud
```

This should be configured as an environment variable (e.g. `VITE_CONVEX_URL` or equivalent for the build system obs-web uses). It is a read-only public URL — no secrets are needed for queries.

### 3. Copy the Convex function definitions (or generate them)

obs-web needs to be able to call `api.obsHost.getHost`. There are two approaches:

**Option A — Duplicate the Convex files and generate types locally:**
Copy `convex/schema.ts` and `convex/obsHost.ts` into the obs-web repo under a `convex/` directory, then run `npx convex dev --once` pointed at the same project. This generates the `convex/_generated/` types so `api.obsHost.getHost` resolves.

**Option B — Use a raw HTTP client without generated types:**
Use `ConvexHttpClient` and call the query by string name. This avoids needing the Convex directory in obs-web at all:

```typescript
import { ConvexHttpClient } from "convex/browser";

const client = new ConvexHttpClient("https://useful-pika-111.convex.cloud");
const host = await client.query("obsHost:getHost" as any);
// host.ipAddress, host.interfaceType, etc.
```

**Option C — Use the reactive Convex client (recommended for real-time updates):**
If obs-web uses a framework with reactive state (e.g., Svelte, React), use the Convex reactive client so the IP updates automatically without page refresh:

```typescript
// Example with ConvexClient (non-React)
import { ConvexClient } from "convex/browser";

const client = new ConvexClient("https://useful-pika-111.convex.cloud");
client.onUpdate("obsHost:getHost" as any, {}, (host) => {
  if (host) {
    // host.ipAddress is now available, connect to OBS
  }
});
```

### 4. Implement auto-connect logic

The core behavior obs-web needs:

1. On page load, query `getHost` from Convex
2. If a host record exists, use `host.ipAddress` to construct the OBS WebSocket URL: `ws://{ipAddress}:4455`
3. Auto-connect to that WebSocket URL
4. The OBS WebSocket port is always `4455` (the default) — it is not stored in Convex

#### Connection flow

```
Page loads
  → Query Convex for host IP
  → If IP available:
      → Connect to ws://{ip}:4455
      → If connection fails, show error (host may be offline)
  → If no IP record exists:
      → Show message that no OBS host has been registered
      → Optionally fall back to manual IP entry
```

#### Edge cases to handle

- **No record in Convex** (`getHost` returns `null`): The companion script has never run. Show a message or fall back to manual entry.
- **Stale IP** (host changed networks since last publish): Connection will fail. Show an appropriate error. The `updatedAt` timestamp can be displayed to help the user understand how fresh the data is.
- **OBS not running**: The IP may be correct but OBS isn't running, so the WebSocket connection will be refused. This is the same error as today's manual flow.
- **Multiple users**: Multiple obs-web clients can read the same Convex record simultaneously. This is read-only and safe.

### 5. Preserve manual fallback

The existing manual IP entry UI should remain as a fallback. Auto-connect is the default path, but users should be able to override with a manual IP if needed (e.g., if they're connecting to a different OBS instance).

## WebSocket Port

The OBS WebSocket server port is **4455** (the OBS default). This is fixed and not published to Convex. obs-web should hardcode or default to this port. If obs-web already has a port configuration field, it can keep its current default.

## Authentication Context

obs-web-companion does not handle authentication. The obs-web fork has separate WorkOS-based authentication that controls who can access the remote control. The Convex `getHost` query is unauthenticated — it's a simple read of the host IP. If authentication is needed on the Convex query in the future, it would be added to the Convex function definition in obs-web-companion and coordinated between both repos.

## Testing the Integration

1. On the OBS host machine, run `npm run publish-ip` in the obs-web-companion project to publish the current IP
2. Verify the record exists in the Convex dashboard at https://dashboard.convex.dev (project: obs-web-companion, table: hostConfig)
3. Load obs-web in a browser — it should read the IP from Convex and auto-connect to `ws://{ip}:4455`
4. On the host machine, run `npm run publish-ip` again after a network change — obs-web should pick up the new IP (immediately if using a reactive client, or on next page load if using a one-shot query)

## Summary of Key Facts

| Item | Value |
|------|-------|
| Convex deployment URL | `https://useful-pika-111.convex.cloud` |
| Convex query to call | `obsHost:getHost` (or `api.obsHost.getHost` with generated types) |
| Data returned | `{ ipAddress, interfaceType, interfaceName, updatedAt }` |
| OBS WebSocket port | `4455` (hardcoded, not in Convex) |
| WebSocket URL format | `ws://{ipAddress}:4455` |
| Authentication on query | None (public read) |
| npm package needed | `convex` |
