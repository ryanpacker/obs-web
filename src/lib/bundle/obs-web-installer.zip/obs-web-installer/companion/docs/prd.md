# Product Requirements Document

## Overview

obs-web-companion is a pair of macOS utility scripts that run on an OBS Studio host machine. The primary script detects the machine's local IP address and publishes it to a Convex database, eliminating the need for remote control users to manually discover and enter the OBS host's IP. A secondary wrapper script combines IP publishing with launching OBS, presenting a seamless "launch OBS" experience via a desktop/dock icon.

These scripts support [obs-web](https://github.com/Niek/obs-web), a browser-based OBS remote control. Together with authentication and auto-connect changes in a [forked obs-web](https://github.com/ryanpacker/obs-web), they enable a zero-friction workflow: an authorized user opens a URL and is immediately connected to OBS.

## Goals

1. **Zero-touch IP discovery** — The current OBS host IP is always available in Convex so that authenticated obs-web users never need to enter an IP address manually
2. **Reliable interface selection** — When multiple network interfaces are active, consistently prefer wired Ethernet over Wi-Fi and warn the user if wired is unavailable
3. **Standalone IP publishing** — The IP publisher script can be run independently at any time, whether OBS is running or not, to update the published IP
4. **Transparent OBS launch** — A wrapper script publishes the IP and then launches OBS, packaged with an OBS-like icon for the dock/desktop so the experience feels like launching OBS itself

## Non-Goals

1. **Authentication/access control** — Handled in the obs-web fork via WorkOS, not this repo
2. **Auto-connect logic** — Handled in the obs-web fork, not this repo
3. **Port management** — The OBS WebSocket port is fixed and never changes; this tool does not publish or manage it
4. **OBS configuration or management** — These scripts do not configure OBS settings, scenes, or sources
5. **Multi-OBS-instance support** — Designed for a single known OBS instance
6. **Cross-platform support** — macOS only

## User Stories

1. As an OBS operator, I want to double-click a single icon on my dock to launch OBS so that the IP is automatically published without any extra steps
2. As an OBS operator, I want to run the IP publisher script after switching from Wi-Fi to Ethernet so that the correct wired IP is published without restarting OBS
3. As an OBS operator, I want to be warned if the script falls back to a Wi-Fi address so that I know the wired connection isn't available
4. As an OBS operator, I want clear error messages if something goes wrong (e.g., Convex unreachable) so that I can troubleshoot without guessing
5. As a remote control user, I want the current OBS IP to always be available in Convex so that my obs-web session connects automatically

## Constraints

1. **macOS only** — The OBS host machine runs macOS; scripts use macOS-specific tooling for network interface detection
2. **Convex as data store** — A new Convex project must be created; the IP publisher uses the Convex SDK to write the host IP
3. **TypeScript runtime** — Scripts are implemented in TypeScript (run via a Node.js-compatible runtime) to leverage the Convex JS/TS SDK directly, keeping the implementation simple and cohesive

## Success Criteria

1. Running the IP publisher script publishes the correct local IP address to Convex
2. When both wired Ethernet and Wi-Fi are active, the script publishes the wired Ethernet IP
3. When only Wi-Fi is available, the script publishes the Wi-Fi IP and warns the user
4. When no network is available or Convex is unreachable, the script fails gracefully with a clear error message
5. Running the IP publisher while OBS is already open updates the IP without affecting OBS
6. The wrapper script publishes the IP and then launches OBS in a single user action
7. The wrapper script can be placed on the dock with an OBS-like icon and behaves like a native app launcher
