# Critical Learnings

A curated list of important insights, patterns, and decisions that should inform future work.

---

## Distribution

### The OBS Launcher .app is shipped with a different `launch` script than the dev/template version in this repo

**Context:** Debugging why the launcher works from a terminal but not always when double-clicked from the Desktop on a broadcast machine.

**Insight:** The obs-web installer (`../obs-web/scripts/install-template.sh`) overwrites `companion/app/launch` at install time with a heredoc-generated script that bakes in absolute paths (`COMPANION_DIR`, `OBS_WEB_DIR`) and also starts the obs-web server on port 8080. The `app/launch` in this repo is **only used for local dev** (when the .app lives inside the repo). The two scripts have diverged before.

**Implication:** Any change to launcher behavior must be made in **both places**:
1. `app/launch` (this repo) — dev/template
2. `scripts/install-template.sh` heredoc starting at the `cat > "$INSTALL_DIR/companion/app/launch"` line (sibling obs-web repo) — what actually ships

Re-run `bash app/build-app.sh` after touching the dev launcher. The broadcast machine needs the installer re-run (or the launch script inside `~/Desktop/OBS Launcher.app/Contents/MacOS/launch` manually replaced) to pick up changes.

## Observability

### Pipe-to-`logger` masks exit codes

**Context:** Dock-launched OBS Launcher would silently fail with no visible feedback.

**Insight:** `npx tsx src/launch-obs.ts 2>&1 | logger -t "OBS Launcher"` discards tsx's exit code — `logger` always exits 0, so the pipeline returns success even when tsx crashes. Combined with `set -e` not being enabled, every failure mode (Convex unreachable, OBS not installed, missing dep, bad CWD) was invisible.

**Implication:** Both launch scripts now `tee` to `~/Library/Logs/OBSLauncher/launch.log` and capture the real exit code via `${PIPESTATUS[0]}`. When debugging a broadcast-machine failure, `tail -n 200 ~/Library/Logs/OBSLauncher/launch.log` is the first thing to read.

## Operations

### Operator recovery runbook

**Context:** A pile of theoretical failure modes exists around wake-from-sleep (stale Convex IP, wedged `node build` server, transient DNS, etc.). Most are real but rare, and adding code for each carries its own complexity. We deliberately chose to lean on a human runbook for recovery rather than chase every edge case in code.

**Insight:** Two-step recovery covers essentially every failure mode short of disk corruption or hardware fault:

1. **Quit OBS, double-click the OBS Launcher icon again.** Handles a stuck OBS process, stale OBS WebSocket state, and triggers a fresh IP publish to Convex.
2. **If that doesn't fix it, restart the laptop and double-click the launcher.** Handles wedged `node build` server, network state corruption, stale LaunchServices preferences, post-update weirdness, and most macOS sleep-related drift.

**Implication:** When triaging an operator complaint, ask them to try (1) first, then (2). Reach for code changes only if both fail or the failure recurs after every reboot. Several smaller defensive fixes are filed under `docs/backlog/launcher-resilience.md` for when we decide to harden further; the larger "auto-publish IP on wake" work (which is the only thing that *actually* dissolves the underlying issue) is filed at `docs/backlog/auto-republish-on-wake.md`.
