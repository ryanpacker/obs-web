# Critical Learnings

A curated list of important insights, patterns, and decisions that should inform future work.

---

## Distribution

### The OBS Launcher .app is shipped with a different `launch` script than the dev/template version in this repo

**Context:** Debugging why the launcher works from a terminal but not always when double-clicked from the Desktop on a broadcast machine.

**Insight:** The obs-web installer (`../obs-web/scripts/install-template.sh`) overwrites `companion/app/launch` at install time with a heredoc-generated script that bakes in absolute paths (`COMPANION_DIR`, `OBS_WEB_DIR`) and also starts the obs-web server on port 8080. The `app/launch` in this repo is **only used for local dev** (when the .app lives inside the repo). The two scripts have diverged before.

**Implication:** Any change to launcher behavior must be made in **both places**:
1. `app/launch` (this repo) — dev/template
2. `scripts/install-template.sh` heredoc starting at the `cat > "$INSTALL_DIR/companion/app/launch"` line (sibling obs-web repo) — what actually ships

Re-run `bash app/build-app.sh` after touching the dev launcher. The broadcast machine needs the installer re-run (or the launch script inside `~/Desktop/OBS Launcher.app/Contents/MacOS/launch` manually replaced) to pick up changes.

## Observability

### Pipe-to-`logger` masks exit codes

**Context:** Dock-launched OBS Launcher would silently fail with no visible feedback.

**Insight:** `npx tsx src/launch-obs.ts 2>&1 | logger -t "OBS Launcher"` discards tsx's exit code — `logger` always exits 0, so the pipeline returns success even when tsx crashes. Combined with `set -e` not being enabled, every failure mode (Convex unreachable, OBS not installed, missing dep, bad CWD) was invisible.

**Implication:** Both launch scripts now `tee` to `~/Library/Logs/OBSLauncher/launch.log` and capture the real exit code via `${PIPESTATUS[0]}`. When debugging a broadcast-machine failure, `tail -n 200 ~/Library/Logs/OBSLauncher/launch.log` is the first thing to read.
