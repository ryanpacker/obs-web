# obs-web-companion: Pre-PRD

## Context

[obs-web](https://github.com/Niek/obs-web) is an open-source browser-based remote control for OBS Studio. It connects to OBS via the OBS WebSocket plugin. We maintain a [fork](https://github.com/ryanpacker/obs-web) that we host ourselves to control a specific OBS instance.

Today, using obs-web requires two manual steps:

1. Entering the IP address of the machine running OBS
2. Entering the OBS WebSocket password

This is friction we want to eliminate.

## Problem

The OBS host machine's IP address changes from time to time (e.g., DHCP lease changes, switching between network connections). Every time the IP changes, every user of the remote control has to find out the new address and type it in. The WebSocket password is also something users need to know and enter, even though it never changes.

There is no access control on the remote control — anyone with the URL can attempt to connect.

## Desired Outcome

An authorized user opens the hosted URL, authenticates, and is immediately connected to OBS. No IP address, no password, no manual steps.

## Solution: Three Components

### 1. IP Publisher Script (this repo)

A script that runs on the OBS host machine. It:

- Detects the machine's local IP address
- When multiple network interfaces are active, prefers the wired Ethernet connection over Wi-Fi
- Writes the IP address to a Convex database (port is not stored — it is fixed and never changes in practice)
- Launches OBS after publishing the IP

The script is packaged with an OBS-like icon and placed on the desktop and dock. To the end user, it feels like launching OBS — they double-click the icon and OBS opens. Behind the scenes, the IP has been published.

The script can also be run standalone after OBS is already running. This covers the case where OBS was started before the Ethernet cable was plugged in: the user plugs in, runs the script again, the IP updates in Convex, and OBS (already running) is unaffected.

### 2. Authentication Layer (in the obs-web fork)

Using WorkOS, access to the remote control is gated behind authentication:

- Only users with provisioned accounts can access the app
- This replaces the current model where anyone with the URL can connect

### 3. Auto-Connect (in the obs-web fork)

For authenticated users, the obs-web app:

- Reads the most recent IP address from Convex on load
- Auto-populates or auto-connects to the OBS WebSocket server at that address
- Supplies the WebSocket password automatically — users never see or need it

## Repository Boundaries

- **obs-web-companion (this repo):** The IP publisher script. It is a standalone utility that runs on the OBS host machine. Different runtime, different machine, different concerns.
- **obs-web fork:** The authentication layer and auto-connect logic. These are modifications to the obs-web SvelteKit app, designed to minimize merge conflicts with the upstream project.
