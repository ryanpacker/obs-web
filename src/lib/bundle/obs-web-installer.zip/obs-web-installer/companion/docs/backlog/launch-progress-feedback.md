# Launcher: visible feedback during launch

## Problem

When the user double-clicks the OBS Launcher icon, there is no on-screen indication that anything is happening until OBS itself opens. If anything takes more than ~2 seconds (IP detection, Convex publish, obs-web server cold start, OBS launch), the user has no idea whether the click registered, the launcher is working, or it's already broken. We hit exactly this confusion during the 2026-05-17 debugging session: a dock click produced no visible output, no error, no progress.

## Acceptance bar

If from double-click to OBS-visible takes more than ~2 seconds, show *something*. Options to consider:

1. **macOS notification** via `osascript -e 'display notification ...'` at start ("Publishing IP, launching OBS…") and on completion/failure.
2. **A tiny status window** via `osascript -e 'tell app "System Events" to display dialog ...'` — works but blocks until dismissed, so use sparingly (success/error only, not progress).
3. **Dock badge / icon bounce** while in-flight — more native feel, but requires the .app to handle Apple Events (current bash-script wrapper doesn't).
4. **Re-package as a Platypus / Automator app** that wraps the script in a real Cocoa shell with menu-bar status. Higher effort, much better UX.

## Constraints

- Must work whether or not OBS is already running (the launcher can be re-triggered to update IP).
- Must not block the launch path (no modal dialogs on the happy path).
- Should be visible even when OBS launches successfully — silent success is also confusing.

## Status

Captured during the 2026-05-17 logging-and-fix session at the user's request. Not yet started.
