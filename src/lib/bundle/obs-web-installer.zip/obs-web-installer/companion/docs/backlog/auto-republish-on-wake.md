# Auto-republish IP on wake / network change

## Problem

The launcher publishes the host IP to Convex only when invoked. If the broadcast laptop sleeps, wakes on a different network (or after a DHCP lease renewal returns a different address), and the operator does *not* double-click the launcher, the IP in Convex stays stale. obs-web auto-connect from phones then points at the wrong address — silent failure from the operator's perspective, opaque "can't connect to host" from the phone's.

This is the single largest realistic failure mode in production use. It is **not** covered by the "quit OBS + relaunch, or reboot" operator runbook because the operator may not realize anything is wrong until someone else complains.

## Why this isn't trivial

We need IP republish to fire automatically on:

1. **Login / boot** — `RunAtLoad` LaunchAgent
2. **Wake from sleep** — there's no direct LaunchAgent trigger; conventional approach is a small helper bound to `IOPMConnectionCreate` callbacks or via `pmset -g log` watching, or a `sleepwatcher`-style daemon
3. **Network configuration change** — `WatchPaths` on `/Library/Preferences/SystemConfiguration/preferences.plist`, or use the SystemConfiguration framework's `SCDynamicStore` notification

The simplest stack would be a single LaunchAgent that triggers on `RunAtLoad` + `WatchPaths` for network config; wake-only events without a network change are uninteresting because the IP didn't change.

## Acceptance bar

- After wake from sleep on a different network, Convex's `hostConfig` row reflects the new IP within ~10 seconds, with no operator action
- After a DHCP renewal that changes the IP, Convex updates within ~10 seconds
- The republish must not interfere with a currently-running launcher invocation (race condition on Convex publish is benign — both writes are upserts of the same key — but worth thinking through)
- Should NOT launch OBS — this is a publish-only path, distinct from the .app's full launch sequence

## Sketch

```
~/Library/LaunchAgents/com.obs-web-companion.republish.plist
  ProgramArguments: /usr/bin/arch -arm64 /usr/local/bin/node ~/obs-web-remote/companion/node_modules/.bin/tsx ~/obs-web-remote/companion/src/publish-ip.ts
  RunAtLoad: true
  WatchPaths:
    - /Library/Preferences/SystemConfiguration/NetworkInterfaces.plist
    - /Library/Preferences/SystemConfiguration/preferences.plist
  StandardOutPath: ~/Library/Logs/OBSLauncher/republish.log
  StandardErrorPath: ~/Library/Logs/OBSLauncher/republish.log
```

The installer (`install-template.sh`) would need to:
- Write the plist
- `launchctl bootstrap gui/$UID ~/Library/LaunchAgents/com.obs-web-companion.republish.plist`
- On uninstall, `launchctl bootout` to deregister

## Open questions

1. **Debounce.** Network change events can fire in bursts during reconnect. The publish script itself should probably wait for a stable IP before publishing.
2. **Self-publish during launcher run.** If both the LaunchAgent and the .app's launcher run within seconds (operator double-clicks right after wake), we have two concurrent Convex publishes. Both write the same key. Last-writer-wins. Fine, but worth confirming.
3. **`publish-ip.ts` already exists** as a standalone script — verify it has retry/backoff for the wake-time DNS race ([[launcher-resilience]] would address this).
4. **Stale plist after uninstall** — leaving a LaunchAgent registered for an uninstalled binary path is mildly bad form. Need explicit uninstall path.

## Status

Filed 2026-05-17 during a debugging-and-stabilization session. Deferred because the runbook ("if it doesn't work, quit OBS + relaunch, or reboot") covers the immediate operational risk and the LaunchAgent design needs proper thought, not a hack.
