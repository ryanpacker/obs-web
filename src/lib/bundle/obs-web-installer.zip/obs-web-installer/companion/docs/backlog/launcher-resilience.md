# Launcher resilience — small defensive fixes

A bundle of small launcher-script and `publish-ip.ts` fixes that defend against wake-from-sleep edge cases and resource-state drift. None is individually critical given the "reboot if broken" runbook, but each meaningfully reduces how often the runbook needs to be invoked.

## Items

### 1. Convex publish retry with backoff
**Problem:** Right after wake, DNS / Wi-Fi association may take 2–10 seconds. `publishIpBestEffort` in `src/launch-obs.ts` (and the standalone `src/publish-ip.ts`) fires the mutation once. If DNS isn't resolving yet, the error is caught, "Failed to publish IP" is logged, the launcher proceeds — OBS opens but Convex has the old IP.

**Fix:** Wrap the mutation in 3 attempts with 1s/3s/7s backoff before falling through to the existing error path. Affects both files (the `publishIpBestEffort` helper and `src/publish-ip.ts`).

### 2. IP-detection retry on transient empty result
**Problem:** Same wake-window — `networksetup`/`ifconfig` may be transitional. `detect-ip.ts` could return only a link-local / self-assigned / loopback address (or nothing) if called within the first few seconds after wake.

**Fix:** If `detectIp()` returns no routable interface, retry every 1s up to 10s before giving up. Goes in `src/detect-ip.ts`.

### 3. Server-spawn verification
**Problem:** Installed launcher does `nohup ... node build & disown`. If node crashes immediately (missing file, port stolen by something between the check and the spawn, esbuild architecture mismatch revisited via a future macOS quirk), the launcher logs `pid=X (detached)` and moves on. obs-web is silently down — operator finds out later when phones can't connect.

**Fix:** After the spawn, `sleep 1 && curl -m 3 http://localhost:8080/` and log the result. Don't fail the launcher (OBS launch is independent and more important to the operator), but a `WARNING: obs-web server did not respond to health check after spawn` in the log gives a debugging hint when "the phones can't connect" complaint comes in. Goes in `install-template.sh` heredoc.

### 4. Log rotation
**Problem:** `~/Library/Logs/OBSLauncher/launch.log` is append-only. Server stdout/stderr also tees there. Over months of daily use this could hit hundreds of MB. Not a launcher failure but a disk-fill risk on a single-purpose laptop.

**Fix:** At the top of the launch script, if `~/Library/Logs/OBSLauncher/launch.log` is over 5MB, rotate it to `.1` (overwriting any existing `.1`). Two rotations of bounded size, no compression, no cron — just a one-shot at script start. ~5 lines of bash.

## Status

Filed 2026-05-17 during a debugging-and-stabilization session. Tier 1 was reduced to just adding `curl -m 3` on the existing health check (defends against the same hang-then-not-responding dialog that prompted this whole session). The rest live here.

Order of value if implementing later: 1 > 2 > 3 > 4.
