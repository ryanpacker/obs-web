import { execSync } from "node:child_process";
import * as os from "node:os";

export interface DetectedIp {
  ipAddress: string;
  interfaceType: "Ethernet" | "Wi-Fi";
  interfaceName: string;
}

interface HardwarePort {
  portName: string;
  device: string;
}

function parseHardwarePorts(): HardwarePort[] {
  const output = execSync("networksetup -listallhardwareports", {
    encoding: "utf-8",
  });

  const ports: HardwarePort[] = [];
  let currentPort: Partial<HardwarePort> = {};

  for (const line of output.split("\n")) {
    const portMatch = line.match(/^Hardware Port:\s*(.+)/);
    if (portMatch) {
      currentPort = { portName: portMatch[1] };
      continue;
    }

    const deviceMatch = line.match(/^Device:\s*(\S+)/);
    if (deviceMatch && currentPort.portName) {
      ports.push({
        portName: currentPort.portName,
        device: deviceMatch[1],
      });
      currentPort = {};
    }
  }

  return ports;
}

function isEthernetPort(portName: string): boolean {
  return /ethernet/i.test(portName);
}

function isWifiPort(portName: string): boolean {
  return /wi-fi|wifi/i.test(portName);
}

export function detectIp(): DetectedIp {
  const hardwarePorts = parseHardwarePorts();
  const networkInterfaces = os.networkInterfaces();

  let ethernetResult: DetectedIp | null = null;
  let wifiResult: DetectedIp | null = null;

  for (const port of hardwarePorts) {
    const ifaces = networkInterfaces[port.device];
    if (!ifaces) continue;

    const ipv4 = ifaces.find((i) => i.family === "IPv4" && !i.internal);
    if (!ipv4) continue;

    if (isEthernetPort(port.portName) && !ethernetResult) {
      ethernetResult = {
        ipAddress: ipv4.address,
        interfaceType: "Ethernet",
        interfaceName: `${port.portName} (${port.device})`,
      };
    } else if (isWifiPort(port.portName) && !wifiResult) {
      wifiResult = {
        ipAddress: ipv4.address,
        interfaceType: "Wi-Fi",
        interfaceName: `${port.portName} (${port.device})`,
      };
    }
  }

  if (ethernetResult) {
    return ethernetResult;
  }

  if (wifiResult) {
    console.warn(
      `⚠ No Ethernet connection found. Falling back to Wi-Fi: ${wifiResult.ipAddress} (${wifiResult.interfaceName})`
    );
    return wifiResult;
  }

  throw new Error(
    "No usable network interface found. Neither Ethernet nor Wi-Fi has an active IPv4 address."
  );
}
