import dotenv from "dotenv";
dotenv.config({ path: ".env.local" });

import { ConvexHttpClient } from "convex/browser";
import { api } from "../convex/_generated/api.js";
import { detectIp } from "./detect-ip.js";

function getConvexUrl(): string {
  const url = process.env.CONVEX_URL;
  if (!url) {
    throw new Error(
      "CONVEX_URL is not set. Run `npx convex dev` to create a project and generate .env.local."
    );
  }
  return url;
}

async function main() {
  const detected = detectIp();
  console.log(
    `Detected IP: ${detected.ipAddress} (${detected.interfaceType}, ${detected.interfaceName})`
  );

  const convexUrl = getConvexUrl();
  const client = new ConvexHttpClient(convexUrl);

  await client.mutation(api.obsHost.publishIp, {
    ipAddress: detected.ipAddress,
    interfaceType: detected.interfaceType,
    interfaceName: detected.interfaceName,
  });

  console.log(`Published IP to Convex: ${detected.ipAddress}`);
}

main().catch((err) => {
  console.error("Failed to publish IP:", err.message);
  process.exit(1);
});
