import dotenv from "dotenv";
dotenv.config({ path: ".env.local" });

import { execSync } from "node:child_process";
import { ConvexHttpClient } from "convex/browser";
import { api } from "../convex/_generated/api.js";
import { detectIp } from "./detect-ip.js";

function getConvexUrl(): string {
  const url = process.env.CONVEX_URL;
  if (!url) {
    throw new Error(
      "CONVEX_URL is not set. Run `npx convex dev` to create a project and generate .env.local."
    );
  }
  return url;
}

async function publishIpBestEffort() {
  try {
    const detected = detectIp();
    console.log(
      `Detected IP: ${detected.ipAddress} (${detected.interfaceType}, ${detected.interfaceName})`
    );

    const convexUrl = getConvexUrl();
    const client = new ConvexHttpClient(convexUrl);

    await client.mutation(api.obsHost.publishIp, {
      ipAddress: detected.ipAddress,
      interfaceType: detected.interfaceType,
      interfaceName: detected.interfaceName,
    });

    console.log(`Published IP to Convex: ${detected.ipAddress}`);
  } catch (err) {
    console.error(
      "Failed to publish IP (continuing to launch OBS):",
      err instanceof Error ? err.message : err
    );
  }
}

function launchObs() {
  console.log("Launching OBS...");
  execSync("open -a 'OBS'");
}

async function main() {
  await publishIpBestEffort();
  launchObs();
}

main().catch((err) => {
  console.error("Unexpected error:", err.message);
  // Still try to launch OBS even if something unexpected went wrong
  try {
    launchObs();
  } catch {
    // nothing more we can do
  }
  process.exit(1);
});
