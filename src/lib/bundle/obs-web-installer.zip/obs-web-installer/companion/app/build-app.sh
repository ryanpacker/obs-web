#!/bin/bash
set -euo pipefail

# Build the OBS Launcher .app bundle

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
APP_DIR="$SCRIPT_DIR/OBS Launcher.app"

echo "Building OBS Launcher.app..."

# Clean previous build
rm -rf "$APP_DIR"

# Create .app directory structure
mkdir -p "$APP_DIR/Contents/MacOS"
mkdir -p "$APP_DIR/Contents/Resources"

# Copy Info.plist
cp "$SCRIPT_DIR/Info.plist" "$APP_DIR/Contents/Info.plist"

# Copy launch script
cp "$SCRIPT_DIR/launch" "$APP_DIR/Contents/MacOS/launch"
chmod +x "$APP_DIR/Contents/MacOS/launch"

# Copy OBS icon if available
OBS_ICON="/Applications/OBS.app/Contents/Resources/AppIcon.icns"
if [ -f "$OBS_ICON" ]; then
  cp "$OBS_ICON" "$APP_DIR/Contents/Resources/AppIcon.icns"
  echo "Copied OBS icon."
else
  echo "⚠ OBS icon not found at $OBS_ICON — app will use a generic icon."
fi

echo "Built: $APP_DIR"
echo ""
echo "To use: drag 'OBS Launcher.app' to your dock, or double-click to run."
echo "If macOS blocks it, right-click > Open, or run: xattr -cr \"$APP_DIR\""
