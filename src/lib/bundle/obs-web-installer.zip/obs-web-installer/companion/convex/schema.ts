import { defineSchema, defineTable } from "convex/server";
import { v } from "convex/values";

export default defineSchema({
  hostConfig: defineTable({
    ipAddress: v.string(),
    interfaceType: v.string(),
    interfaceName: v.string(),
    updatedAt: v.number(),
  }),
});
