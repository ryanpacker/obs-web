import { mutation, query } from "./_generated/server";
import { v } from "convex/values";

export const publishIp = mutation({
  args: {
    ipAddress: v.string(),
    interfaceType: v.string(),
    interfaceName: v.string(),
  },
  handler: async (ctx, args) => {
    const existing = await ctx.db.query("hostConfig").first();

    const data = {
      ipAddress: args.ipAddress,
      interfaceType: args.interfaceType,
      interfaceName: args.interfaceName,
      updatedAt: Date.now(),
    };

    if (existing) {
      await ctx.db.patch(existing._id, data);
    } else {
      await ctx.db.insert("hostConfig", data);
    }
  },
});

export const getHost = query({
  args: {},
  handler: async (ctx) => {
    return await ctx.db.query("hostConfig").first();
  },
});
